## Install the project packages

npm install

## Create or reset the Database (model)

node model.js --create

## Check the Database with a simple query

node model.js

## Run de server

npm start

## Check the API in the browser

http://localhost:9000/graphql

## START your PROJECT!!

## Database params
{
    "dataSource": "Cluster0",
    "database": "devdb",
    "collection": "User"
}

## 
URL Endpoint: https://data.mongodb-api.com/app/data-nmodv/endpoint/data/beta

##
API Key:
"bodrsyD72a8e60yAp71vLhm2uUUoWmDgwij09sUCFT3GU54pssuRUlO3tgICGdTA"